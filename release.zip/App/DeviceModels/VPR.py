VPR = [
  [
    { "id": "01", "name": "Verificación del cable de alimentación AC", "field": "picker", "value": "" },
    { "id": "02", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "03", "name": "Verificación del enchufe hembra y macho AC", "field": "picker", "value": "" },
    { "id": "04", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "05", "name": "Verificación del interruptor de encendido", "field": "picker", "value": "" },
    { "id": "06", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "07", "name": "Pruebas del panel frontal táctil", "field": "picker", "value": "" },
    { "id": "08", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "09", "name": "Pruebas indicadores visuales", "field": "picker", "value": "" },
    { "id": "10", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "11", "name": "Pruebas de control automático de luz", "field": "picker", "value": "" },
    { "id": "12", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "13", "name": "Pruebas de control manual de luz", "field": "picker", "value": "" },
    { "id": "14", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "15", "name": "Prueba de registro en tarjeta de memoria", "field": "picker", "value": "" },
    { "id": "16", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "17", "name": "Funcionamiento modo release, zoom y tono de color", "field": "picker", "value": "" },
    { "id": "18", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "19", "name": "Funcionamiento modo NBI", "field": "picker", "value": "" },
    { "id": "20", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "21", "name": "Funcionamiento modo RDI", "field": "picker", "value": "" },
    { "id": "22", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "23", "name": "Funcionamiento modo TXI", "field": "picker", "value": "" },
    { "id": "24", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "25", "name": "Funcionamiento balance de blancos y NBI", "field": "picker", "value": "" },
    { "id": "26", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "27", "name": "Funcionamiento de salida de video SDI", "field": "picker", "value": "" },
    { "id": "28", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "29", "name": "Funcionamiento de ventiladores", "field": "picker", "value": "" },
    { "id": "30", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "31", "name": "Limpieza y condición física del gabinete", "field": "picker", "value": "" },
    { "id": "32", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "33", "name": "Limpieza interna de tarjetas electrónicas", "field": "picker", "value": "" },
    { "id": "34", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "35", "name": "Verificación del teclado de ingreso de datos", "field": "picker", "value": "" },
    { "id": "36", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "37", "name": "Estado conexión endoscopio", "field": "picker", "value": "" },
    { "id": "38", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "39", "name": "Funcionamiento de la unidad Led / Xenon", "field": "picker", "value": "" },
    { "id": "99", "name": "Horas", "field": "number", "value": "0" },
    { "id": "40", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "41", "name": "Funcionamiento de la insuflación", "field": "picker", "value": "" },
    { "id": "42", "name": "Comentarios", "field": "area", "value": "" }
  ]
]
