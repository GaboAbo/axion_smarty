ECG = [
  [
    { "id": "01", "name": "Verificación de la etiqueta de serie y modelo", "field": "picker", "value": "" },
    { "id": "02", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "03", "name": "Verificación del estado de la carcaza", "field": "picker", "value": "" },
    { "id": "04", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "05", "name": "Estado del pedal y cable", "field": "picker", "value": "" },
    { "id": "06", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "07", "name": "Estado del cable de poder", "field": "picker", "value": "" },
    { "id": "08", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "09", "name": "Verificación de la conexión a tierra de protección", "field": "picker", "value": "" },
    { "id": "10", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "11", "name": "Verificación de la conexión principal y botón de encendido", "field": "picker", "value": "" },
    { "id": "12", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "13", "name": "Estado de la conexiones de los cables internos", "field": "picker", "value": "" },
    { "id": "14", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "15", "name": "Verificación de botones y panel frontal", "field": "picker", "value": "" },
    { "id": "16", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "17", "name": "Verificación de la pantalla táctil", "field": "picker", "value": "" },
    { "id": "18", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "19", "name": "Estado de los 4 soportes de goma", "field": "picker", "value": "" },
    { "id": "20", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "21", "name": "Limpieza de las tarjetas electronicas", "field": "picker", "value": "" },
    { "id": "22", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "23", "name": "Estado del carro de transporte", "field": "picker", "value": "" },
    { "id": "24", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "25", "name": "Estado del disparador de lapiz y/o pedal", "field": "picker", "value": "" },
    { "id": "26", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "27", "name": "Verificación de los conectores frontales", "field": "picker", "value": "" },
    { "id": "28", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "29", "name": "Prueba de seguridad electrica", "field": "picker", "value": "" },
    { "id": "30", "name": "Comentarios", "field": "area", "value": "" }
  ]
]
