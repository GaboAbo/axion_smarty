LIS = [
  [
    {
        "id": "01",
        "name": "Verificación del cable de alimentación AC",
        "field": "picker",
        "value": ""
    },
    {
        "id": "02",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "03",
        "name": "Verificación del enchufe hembra/macho AC",
        "field": "picker",
        "value": ""
    },
    {
        "id": "04",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "05",
        "name": "Verificación del interlock lámpara",
        "field": "picker",
        "value": ""
    },
    {
        "id": "06",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "07",
        "name": "Comprobación piloto LED",
        "field": "picker",
        "value": ""
    },
    {
        "id": "08",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "09",
        "name": "Inspección de los pines de control",
        "field": "picker",
        "value": ""
    },
    {
        "id": "10",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "11",
        "name": "Verificación del estado de portafusibles",
        "field": "picker",
        "value": ""
    },
    {
        "id": "12",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "13",
        "name": "Prueba de botoneras panel frontal",
        "field": "picker",
        "value": ""
    },
    {
        "id": "14",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "15",
        "name": "Prueba de indicadores visuales",
        "field": "picker",
        "value": ""
    },
    {
        "id": "16",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "17",
        "name": "Prueba de control de luz automático",
        "field": "picker",
        "value": ""
    },
    {
        "id": "18",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "19",
        "name": "Pruebas de control de luz manual",
        "field": "picker",
        "value": ""
    },
    {
        "id": "20",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "21",
        "name": "Comprobación de funcionamiento NBI / IR",
        "field": "picker",
        "value": ""
    },
    {
        "id": "22",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "23",
        "name": "Usos de la lámpara de xenón",
        "field": "picker",
        "value": ""
    },
    {
        "id": "99",
        "name": "Usos de la lámpara de xenón",
        "field": "number",
        "value": "0"
    },
    {
        "id": "24",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "25",
        "name": "Comprobación de la lámpara de emergencia",
        "field": "picker",
        "value": ""
    },
    {
        "id": "26",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "27",
        "name": "Control de brillo",
        "field": "picker",
        "value": ""
    },
    {
        "id": "28",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "29",
        "name": "Pruebas nivel de insuflación de aire",
        "field": "picker",
        "value": ""
    },
    {
        "id": "30",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "31",
        "name": "Estado de servo carro de lámpara",
        "field": "picker",
        "value": ""
    },
    {
        "id": "32",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "33",
        "name": "Verificación del sistema de comprobación de lámpara",
        "field": "picker",
        "value": ""
    },
    {
        "id": "34",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "35",
        "name": "Revisión del estado del conector de video In",
        "field": "picker",
        "value": ""
    },
    {
        "id": "36",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "37",
        "name": "Revisión del estado de conector de video Out",
        "field": "picker",
        "value": ""
    },
    {
        "id": "38",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "39",
        "name": "Limpieza de contactos electrónicos internos",
        "field": "picker",
        "value": ""
    },
    {
        "id": "40",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "41",
        "name": "Revisión del conector de control de luz",
        "field": "picker",
        "value": ""
    },
    {
        "id": "42",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "43",
        "name": "Posición de torretas",
        "field": "picker",
        "value": ""
    },
    {
        "id": "44",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "45",
        "name": "Posición del sensor de temperatura",
        "field": "picker",
        "value": ""
    },
    {
        "id": "46",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "47",
        "name": "Comprobación del funcionamiento ventilador 1",
        "field": "picker",
        "value": ""
    },
    {
        "id": "48",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "49",
        "name": "Comprobación del funcionamiento ventilador 2",
        "field": "picker",
        "value": ""
    },
    {
        "id": "50",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "51",
        "name": "Inspección del estado del Gabinete",
        "field": "picker",
        "value": ""
    },
    {
        "id": "52",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ],
  [
    {
        "id": "53",
        "name": "Pruebas de comunicación",
        "field": "picker",
        "value": ""
    },
    {
        "id": "54",
        "name": "Comentarios",
        "field": "area",
        "value": ""
    }
  ]
]
