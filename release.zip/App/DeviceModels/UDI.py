UDI = [
  [
    { "id": "01", "name": "Estado del cable de poder AC", "field": "picker", "value": "" },
    { "id": "02", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "03", "name": "Estado del computador y sistema operativo", "field": "picker", "value": "" },
    { "id": "04", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "05", "name": "Estado de la impresora", "field": "picker", "value": "" },
    { "id": "06", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "07", "name": "Tamaño base de datos sistema de captura", "field": "picker", "value": "" },
    { "id": "08", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "09", "name": "Entrega de respaldo de base de datos al cliente", "field": "picker", "value": "" },
    { "id": "10", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "11", "name": "Estado del capturador de video", "field": "picker", "value": "" },
    { "id": "12", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "13", "name": "Estado del dispositivo de juego (pedal)", "field": "picker", "value": "" },
    { "id": "14", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "15", "name": "Prueba de captura remota", "field": "picker", "value": "" },
    { "id": "16", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "17", "name": "Prueba de imagen de procedimiento", "field": "picker", "value": "" },
    { "id": "18", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "19", "name": "Inspección visual de cableados", "field": "picker", "value": "" },
    { "id": "20", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "21", "name": "Flujo completo de elaboración e impresión de informe", "field": "picker", "value": "" },
    { "id": "22", "name": "Comentarios", "field": "area", "value": "" }
  ],
  [
    { "id": "23", "name": "Configuración de plataforma para sistema de captura", "field": "picker", "value": "" },
    { "id": "24", "name": "Comentarios", "field": "area", "value": "" }
  ]
]
