PMP = [
    [
        {
            "id": "15",
            "name": "Funcionamiento del interruptor principal de encendido",
            "field": "picker",
            "value": "",
        },
        {
            "id": "16",
            "name": "Comentarios",
            "field": "area",
            "value": "",
        },
    ],
    [
        {
            "id": "17",
            "name": "Funcionamiento del interruptor stand by",
            "field": "picker",
            "value": "",
        },
        {
            "id": "18",
            "name": "Comentarios",
            "field": "area",
            "value": "",
        },
    ],
    [
        {
            "id": "19",
            "name": "Funcionamiento de selector e indicador de funciones panel frontal",
            "field": "picker",
            "value": "",
        },
        {
            "id": "20",
            "name": "Comentarios",
            "field": "area",
            "value": "",
        },
    ],
    [
        {
            "id": "21",
            "name": "Funcionamiento e inspeccion de cabezal de bomba",
            "field": "picker",
            "value": "",
        },
        {
            "id": "22",
            "name": "Comentarios",
            "field": "area",
            "value": "",
        },
    ],
    [
        {
            "id": "23",
            "name": "Verificacion de pedal neumático",
            "field": "picker",
            "value": "",
        },
        {
            "id": "24",
            "name": "Comentarios",
            "field": "area",
            "value": "",
        },
    ],
    [
        {
            "id": "25",
            "name": "Verificación del temporizador de seguridad del pedal",
            "field": "picker",
            "value": "",
        },
        {
            "id": "26",
            "name": "Comentarios",
            "field": "area",
            "value": "",
        },
    ],
    [
        {
            "id": "27",
            "name": "Verificación de la limpieza de tarjetas electrónicas",
            "field": "picker",
            "value": "",
        },
        {
            "id": "28",
            "name": "Comentarios",
            "field": "area",
            "value": "",
        },
    ],
    [
        {
            "id": "29",
            "name": "Verificación de la conexión con el videoprocesador",
            "field": "picker",
            "value": "",
        },
        {
            "id": "30",
            "name": "Comentarios",
            "field": "area",
            "value": "",
        },
    ],
]
