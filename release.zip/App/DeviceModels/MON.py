MON = [
  [
    {
      "id": "01",
      "name": "Verificación del cable de alimentación",
      "field": "picker",
      "value": "",
    },
    {
      "id": "02",
      "name": "Comentarios",
      "field": "area",
      "value": "",
    },
  ],
  [
    {
      "id": "03",
      "name": "Verificación del interruptor de encendido",
      "field": "picker",
      "value": "",
    },
    {
      "id": "04",
      "name": "Comentarios",
      "field": "area",
      "value": "",
    },
  ],
  [
    {
      "id": "05",
      "name": "Verificación del conector de Video In / Out",
      "field": "picker",
      "value": "",
    },
    {
      "id": "06",
      "name": "Comentarios",
      "field": "area",
      "value": "",
    },
  ],
  [
    {
      "id": "07",
      "name": "Verificación de los controles del panel frontal",
      "field": "picker",
      "value": "",
    },
    {
      "id": "08",
      "name": "Comentarios",
      "field": "area",
      "value": "",
    },
  ],
  [
    {
      "id": "09",
      "name": "Verificación de los indicadores visuales (brillo y contraste)",
      "field": "picker",
      "value": "",
    },
    {
      "id": "10",
      "name": "Comentarios",
      "field": "area",
      "value": "",
    },
  ],
  [
    {
      "id": "11",
      "name": "Prueba con barra de colores",
      "field": "picker",
      "value": "",
    },
    {
      "id": "12",
      "name": "Comentarios",
      "field": "area",
      "value": "",
    },
  ],
  [
    {
      "id": "13",
      "name": "Verificación de la fijación del brazo móvil",
      "field": "picker",
      "value": "",
    },
    {
      "id": "14",
      "name": "Comentarios",
      "field": "area",
      "value": "",
    },
  ],
  [
    {
      "id": "15",
      "name": "Ajuste modo de video de acuerdo al video procesador utilizado",
      "field": "picker",
      "value": "",
    },
    {
      "id": "16",
      "name": "Comentarios",
      "field": "area",
      "value": "",
    },
  ],
  [
    {
      "id": "17",
      "name": "Verificación modo 3D",
      "field": "picker",
      "value": "",
    },
    {
      "id": "18",
      "name": "Comentarios",
      "field": "area",
      "value": "",
    },
  ],
  [
    {
      "id": "19",
      "name": "Funcionamiento imagen 4K",
      "field": "picker",
      "value": "",
    },
    {
      "id": "20",
      "name": "Comentarios",
      "field": "area",
      "value": "",
    },
  ]
]